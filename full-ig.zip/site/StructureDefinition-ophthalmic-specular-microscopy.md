# Ophthalmic Specular Microscopy - FHIR4Eyes - A Proposed FHIR Implementation Guide for Ophthalmology v0.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ophthalmic Specular Microscopy**

## Resource Profile: Ophthalmic Specular Microscopy 

| | |
| :--- | :--- |
| *Official URL*:https://YasniiSS.github.io/fhir4eyes/StructureDefinition/ophthalmic-specular-microscopy | *Version*:0.4.0 |
| Draft as of 2026-10-20 | *Computable Name*:OphthalmicSpecularMicroscopy |

 
Represents a corneal endothelial specular microscopy exam. Sourced directly from the FHIR4Eyes Observations catalog (Specular Microscopy section). 

Represents a corneal endothelial specular microscopy exam, as a single `Observation` with one `component` per reported value. Sourced directly from the FHIR4Eyes Observations catalog (Specular Microscopy section).

Endothelial cell density (`density`) is the only required component; the others cover the capture position, analysis method, number of cells analyzed, coefficient of variation, hexagonality, central corneal thickness, and minimum, maximum, average, and standard deviation of cell area. `code` and every component use a laterality-neutral local FHIR4Eyes code ([FHIR4EyesCS](CodeSystem-fhir4eyes-cs.md)), since the only LOINC codes for these concepts are eye-specific. For all components except the capture position, instances add the eye-specific LOINC as a second coding; each component's short description documents both the right eye (OD) and left eye (OS) codes, following the same approach described on [OphthalmicOCTRNFL](StructureDefinition-ophthalmic-oct-rnfl.md). Laterality uses the standard `bodySite` extension referencing [OcularBodyStructure](StructureDefinition-ocular-body-structure.md); the microscope model may be recorded in `device` and the cell counting method in `method`.

**Examples:** [Specular microscopy: right eye](Observation-SpecularMicroscopyRightEyeExample.md)

**Usages:**

* Examples for this Profile: [Observation/SpecularMicroscopyRightEyeExample](Observation-SpecularMicroscopyRightEyeExample.md)
* CapabilityStatements using this Profile: [FHIR4Eyes Server Capability Statement](CapabilityStatement-FHIR4EyesCapabilityStatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/fhir4eyes.core|current/StructureDefinition/StructureDefinition-ophthalmic-specular-microscopy.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ophthalmic-specular-microscopy.csv), [Excel](StructureDefinition-ophthalmic-specular-microscopy.xlsx), [Schematron](StructureDefinition-ophthalmic-specular-microscopy.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ophthalmic-specular-microscopy",
  "url" : "https://YasniiSS.github.io/fhir4eyes/StructureDefinition/ophthalmic-specular-microscopy",
  "version" : "0.4.0",
  "name" : "OphthalmicSpecularMicroscopy",
  "title" : "Ophthalmic Specular Microscopy",
  "status" : "draft",
  "date" : "2026-10-20T20:13:11-03:00",
  "publisher" : "FHIR4Eyes Project",
  "contact" : [{
    "name" : "FHIR4Eyes Project",
    "telecom" : [{
      "system" : "url",
      "value" : "https://YasniiSS.github.io/fhir4eyes"
    }]
  },
  {
    "name" : "Yasna Soto",
    "telecom" : [{
      "system" : "url",
      "value" : "https://YasniiSS.github.io/fhir4eyes"
    }]
  }],
  "description" : "Represents a corneal endothelial specular microscopy exam. Sourced directly\nfrom the FHIR4Eyes Observations catalog (Specular Microscopy section).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001",
      "display" : "World"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation"
    },
    {
      "id" : "Observation.status",
      "path" : "Observation.status",
      "mustSupport" : true
    },
    {
      "id" : "Observation.category",
      "path" : "Observation.category",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.category:exam",
      "path" : "Observation.category",
      "sliceName" : "exam",
      "min" : 1,
      "max" : "1",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "short" : "Identifies this as a specular microscopy exam",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://YasniiSS.github.io/fhir4eyes/CodeSystem/fhir4eyes-cs",
          "code" : "specular-microscopy-panel",
          "display" : "Corneal endothelial specular microscopy"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Observation.subject",
      "path" : "Observation.subject",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.encounter",
      "path" : "Observation.encounter",
      "mustSupport" : true
    },
    {
      "id" : "Observation.effective[x]",
      "path" : "Observation.effective[x]",
      "mustSupport" : true
    },
    {
      "id" : "Observation.note",
      "path" : "Observation.note",
      "mustSupport" : true
    },
    {
      "id" : "Observation.bodySite",
      "path" : "Observation.bodySite",
      "mustSupport" : true
    },
    {
      "id" : "Observation.bodySite.extension:bodySiteEye",
      "path" : "Observation.bodySite.extension",
      "sliceName" : "bodySiteEye",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/bodySite|5.3.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.bodySite.extension:bodySiteEye.value[x]",
      "path" : "Observation.bodySite.extension.value[x]",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://YasniiSS.github.io/fhir4eyes/StructureDefinition/ocular-body-structure"]
      }]
    },
    {
      "id" : "Observation.method",
      "path" : "Observation.method",
      "short" : "Analysis method: automated, manual, or semi-automated cell counting",
      "mustSupport" : true
    },
    {
      "id" : "Observation.device",
      "path" : "Observation.device",
      "short" : "Specular microscope model (e.g. Topcon SP-1P, Konan, Nidek)",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component",
      "path" : "Observation.component",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "code"
        }],
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Observation.component:capturePos",
      "path" : "Observation.component",
      "sliceName" : "capturePos",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:capturePos.code",
      "path" : "Observation.component.code",
      "short" : "Capture position - location of corneal capture (center, paracentral, peripheral)",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://YasniiSS.github.io/fhir4eyes/CodeSystem/fhir4eyes-cs",
          "code" : "specular-capture-position",
          "display" : "Specular microscopy capture position"
        }]
      }
    },
    {
      "id" : "Observation.component:capturePos.value[x]",
      "path" : "Observation.component.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "Observation.component:analysisMethod",
      "path" : "Observation.component",
      "sliceName" : "analysisMethod",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:analysisMethod.code",
      "path" : "Observation.component.code",
      "short" : "Analysis method type. Instances add the eye-specific LOINC as a second coding: 100086-8 (OD) / 100155-1 (OS)",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://YasniiSS.github.io/fhir4eyes/CodeSystem/fhir4eyes-cs",
          "code" : "specular-analysis-method",
          "display" : "Specular microscopy analysis method"
        }]
      }
    },
    {
      "id" : "Observation.component:analysisMethod.value[x]",
      "path" : "Observation.component.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "Observation.component:density",
      "path" : "Observation.component",
      "sliceName" : "density",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:density.code",
      "path" : "Observation.component.code",
      "short" : "Endothelial cell density (CD). Instances add the eye-specific LOINC as a second coding: 100070-2 (OD) / 100071-0 (OS)",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://YasniiSS.github.io/fhir4eyes/CodeSystem/fhir4eyes-cs",
          "code" : "endothelial-cell-density",
          "display" : "Corneal endothelial cell density"
        }]
      }
    },
    {
      "id" : "Observation.component:density.value[x]",
      "path" : "Observation.component.value[x]",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "Observation.component:cellCount",
      "path" : "Observation.component",
      "sliceName" : "cellCount",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:cellCount.code",
      "path" : "Observation.component.code",
      "short" : "Number of cells analyzed (N). Instances add the eye-specific LOINC as a second coding: 100076-9 (OD) / 100077-7 (OS)",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://YasniiSS.github.io/fhir4eyes/CodeSystem/fhir4eyes-cs",
          "code" : "endothelial-cells-counted",
          "display" : "Corneal endothelial cells counted"
        }]
      }
    },
    {
      "id" : "Observation.component:cellCount.value[x]",
      "path" : "Observation.component.value[x]",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "Observation.component:cv",
      "path" : "Observation.component",
      "sliceName" : "cv",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:cv.code",
      "path" : "Observation.component.code",
      "short" : "Coefficient of variation (CV). Instances add the eye-specific LOINC as a second coding: 100072-8 (OD) / 100073-6 (OS), normal <40%",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://YasniiSS.github.io/fhir4eyes/CodeSystem/fhir4eyes-cs",
          "code" : "endothelial-cell-area-cv",
          "display" : "Corneal endothelial cell area coefficient of variation"
        }]
      }
    },
    {
      "id" : "Observation.component:cv.value[x]",
      "path" : "Observation.component.value[x]",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "Observation.component:hexagonality",
      "path" : "Observation.component",
      "sliceName" : "hexagonality",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:hexagonality.code",
      "path" : "Observation.component.code",
      "short" : "Hexagonality (HEX). Instances add the eye-specific LOINC as a second coding: 100074-4 (OD) / 100075-1 (OS), normal >50%",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://YasniiSS.github.io/fhir4eyes/CodeSystem/fhir4eyes-cs",
          "code" : "endothelial-hexagonality",
          "display" : "Corneal endothelial hexagonality"
        }]
      }
    },
    {
      "id" : "Observation.component:hexagonality.value[x]",
      "path" : "Observation.component.value[x]",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "Observation.component:cct",
      "path" : "Observation.component",
      "sliceName" : "cct",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:cct.code",
      "path" : "Observation.component.code",
      "short" : "Central corneal thickness (CCT). Instances add the eye-specific LOINC as a second coding: 79825-6 (OD) / 79826-4 (OS)",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://YasniiSS.github.io/fhir4eyes/CodeSystem/fhir4eyes-cs",
          "code" : "central-corneal-thickness",
          "display" : "Central corneal thickness"
        }]
      }
    },
    {
      "id" : "Observation.component:cct.value[x]",
      "path" : "Observation.component.value[x]",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "Observation.component:minArea",
      "path" : "Observation.component",
      "sliceName" : "minArea",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:minArea.code",
      "path" : "Observation.component.code",
      "short" : "Minimum cell area (MIN). Instances add the eye-specific LOINC as a second coding: 100078-5 (OD) / 100079-3 (OS)",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://YasniiSS.github.io/fhir4eyes/CodeSystem/fhir4eyes-cs",
          "code" : "endothelial-cell-area-min",
          "display" : "Corneal endothelial cell area, minimum"
        }]
      }
    },
    {
      "id" : "Observation.component:minArea.value[x]",
      "path" : "Observation.component.value[x]",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "Observation.component:maxArea",
      "path" : "Observation.component",
      "sliceName" : "maxArea",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:maxArea.code",
      "path" : "Observation.component.code",
      "short" : "Maximum cell area (MAX). Instances add the eye-specific LOINC as a second coding: 100080-1 (OD) / 100081-9 (OS)",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://YasniiSS.github.io/fhir4eyes/CodeSystem/fhir4eyes-cs",
          "code" : "endothelial-cell-area-max",
          "display" : "Corneal endothelial cell area, maximum"
        }]
      }
    },
    {
      "id" : "Observation.component:maxArea.value[x]",
      "path" : "Observation.component.value[x]",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "Observation.component:avgArea",
      "path" : "Observation.component",
      "sliceName" : "avgArea",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:avgArea.code",
      "path" : "Observation.component.code",
      "short" : "Average cell area (AVG). Instances add the eye-specific LOINC as a second coding: 100082-7 (OD) / 100083-5 (OS)",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://YasniiSS.github.io/fhir4eyes/CodeSystem/fhir4eyes-cs",
          "code" : "endothelial-cell-area-mean",
          "display" : "Corneal endothelial cell area, mean"
        }]
      }
    },
    {
      "id" : "Observation.component:avgArea.value[x]",
      "path" : "Observation.component.value[x]",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "Observation.component:sdArea",
      "path" : "Observation.component",
      "sliceName" : "sdArea",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.component:sdArea.code",
      "path" : "Observation.component.code",
      "short" : "Cell area SD. Instances add the eye-specific LOINC as a second coding: 100084-3 (OD) / 100085-0 (OS)",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://YasniiSS.github.io/fhir4eyes/CodeSystem/fhir4eyes-cs",
          "code" : "endothelial-cell-area-sd",
          "display" : "Corneal endothelial cell area, standard deviation"
        }]
      }
    },
    {
      "id" : "Observation.component:sdArea.value[x]",
      "path" : "Observation.component.value[x]",
      "type" : [{
        "code" : "Quantity"
      }]
    }]
  }
}

```
