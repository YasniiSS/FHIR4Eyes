# Home - FHIR4Eyes - A Proposed FHIR Implementation Guide for Ophthalmology v0.2.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://YasniiSS.github.io/fhir4eyes/ImplementationGuide/fhir4eyes.core | *Version*:0.2.0 |
| Draft as of 2026-08-25 | *Computable Name*:FHIR4Eyes |

# FHIR4Eyes

## What is this guide for?

**FHIR4Eyes is a proposed Implementation Guide, not an official HL7 standard.** It is an independent, community-driven effort, shared openly for feedback and discussion.

Eye care generates a huge amount of structured clinical data, including visual acuity measurements, eye pressure readings, imaging studies, surgical procedures, and medications injected directly into the eye. However, there is currently no mature, complete international standard for sharing this data electronically between systems.

**FHIR4Eyes** is a FHIR® Implementation Guide that defines how ophthalmology data should be represented and exchanged, so that different software systems, from primary care clinics to hospital ophthalmology departments, imaging systems, and national health registries, can understand each other's eye care data consistently.

This matters because patients with eye conditions are often seen across multiple care settings over years, sometimes decades. A family doctor makes the first referral, a primary eye care clinic follows up, a hospital specialist takes over more complex cases, and an imaging center runs the diagnostic tests. When these systems can't exchange structured data reliably, patients' clinical history gets fragmented, and care teams either repeat tests unnecessarily or make decisions with an incomplete picture.

## Why does this guide exist?

There is an existing early-stage effort at HL7, the [Eye Care Implementation Guide](https://build.fhir.org/ig/HL7/fhir-eyecare-ig/), but as of this writing it is still in ballot, has significant gaps (no diagnosis, imaging, treatment, or device profiles), and is not yet available as a usable package. FHIR4Eyes was built to cover ophthalmology workflows that aren't addressed anywhere yet, such as imaging studies, treatment plans for intravitreal injections, and implantable devices like intraocular lenses (see [Background](background.md) for the full list). It's meant to be usable today, informed by a real hospital pilot implementation connecting primary and hospital secondary care. And wherever the HL7 Eye Care IG already defines a design pattern, FHIR4Eyes tries to stay aligned with it, so the two efforts can converge rather than diverge.

## Who is this guide for?

* **Software developers** building or integrating systems that handle eye care data, such as EHRs, PACS/imaging systems, or ophthalmology-specific applications. This guide's **Profiles** and **Terminology** pages are the normative reference you'll need.
* **Health informatics and interoperability teams** at hospitals, health ministries, or national health systems who are planning how ophthalmology fits into their broader interoperability strategy. The **Background** and **Use Cases** pages give the "why" before the "how".

## Structure

FHIR4Eyes is published as two related Implementation Guides:

* **FHIR4Eyes Core** (this guide) covers international, resource and terminology level content that isn't tied to any country's regulations.
* **[FHIR4Eyes CL](cl/index.md)** is a Chilean extension, adding the constraints and bindings required for use within Chile's national FHIR core profiles ([`hl7.fhir.cl.clcore`](https://simplifier.net/chilehl7)).

If you're implementing outside Chile, you only need FHIR4Eyes Core. If you're implementing in Chile, you need both.

## Getting started

* New to FHIR? Start with the [official FHIR specification](http://hl7.org/fhir/R4/index.html)
* New to this guide? Read [Background](background.md) next, then [Use Cases](usecases.md)
* Looking for a specific resource profile? Go straight to [Profiles](profiles.md)
* Want to know what "must support" means here? See [Guidance](guidance.md)

## Feedback and community

This is an early-stage, community-driven guide. Feedback, questions, and contributions are welcome.

## Author

**Yasna Soto Sánchez**

Medical Technologist in Ophthalmology and Optometry, Universidad de Chile Master's in Medical Informatics, Universidad de Chile, in collaboration with Universidad de Heidelberg Civil Informatics Engineering student, Universidad San Sebastián

I worked for five years in clinical and hospital settings within ophthalmology units, performing a wide range of specialty examinations and five years in Medical Informatics. I then moved into medical informatics,where my first contribution was standardizing ophthalmic imaging toward the PACS system at Hospital San José, in Independencia, Santiago de Chile. I continue working toward the greatest possible standardization of ophthalmology data, aiming for an interoperable path that allows modality neutrality and a more standardized flow of ophthalmic procedures and records.

