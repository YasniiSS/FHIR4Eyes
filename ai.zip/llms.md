# fhir4eyes.core#0.1.0: FHIR4Eyes - A Proposed FHIR Implementation Guide for Ophthalmology

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Background](background.md)
* [Guidance](guidance.md)
* [Profiles](profiles.md)
* [Security and Privacy](security.md)
* [Terminology](terminology.md)
* [Use Cases](usecases.md)

## Resources

### CodeSystems

* [FHIR4Eyes Care Plan Category Code System](CodeSystem-fhir4eyes-care-plan-category-cs.md)

### ValueSets

* [Low Vision Assessment Value Set](ValueSet-low-vision-assessment-vs.md)
* [Ophthalmic Care Plan Category Value Set](ValueSet-ophthalmic-care-plan-category-vs.md)

### Resource Profiles

* [Convergence Assessment](StructureDefinition-convergence-assessment.md)
* [Corrected Intraocular Pressure](StructureDefinition-corrected-intraocular-pressure.md)
* [Cover Test](StructureDefinition-cover-test.md)
* [Gaze Position Measurement](StructureDefinition-gaze-position-measurement.md)
* [Hirschberg Test](StructureDefinition-hirschberg-test.md)
* [Intraocular Pressure](StructureDefinition-intraocular-pressure.md)
* [Krimsky Test](StructureDefinition-krimsky-test.md)
* [Near Point of Convergence](StructureDefinition-near-point-of-convergence.md)
* [Ocular Body Structure](StructureDefinition-ocular-body-structure.md)
* [Ocular Motility](StructureDefinition-ocular-motility.md)
* [Ophthalmic Care Plan](StructureDefinition-ophthalmic-care-plan.md)
* [Ophthalmic Condition](StructureDefinition-ophthalmic-condition.md)
* [Ophthalmic Device](StructureDefinition-ophthalmic-device.md)
* [Ophthalmic Diagnostic Report](StructureDefinition-ophthalmic-diagnostic-report.md)
* [Ophthalmic Encounter](StructureDefinition-ophthalmic-encounter.md)
* [Ophthalmic Imaging Study](StructureDefinition-ophthalmic-imaging-study.md)
* [Ophthalmic Medication Administration](StructureDefinition-ophthalmic-medication-administration.md)
* [Ophthalmic Medication](StructureDefinition-ophthalmic-medication.md)
* [Ophthalmic Procedure](StructureDefinition-ophthalmic-procedure.md)
* [Ophthalmic Service Request](StructureDefinition-ophthalmic-service-request.md)
* [Ophthalmic Visual Acuity](StructureDefinition-ophthalmic-visual-acuity.md)
* [Pachymetry](StructureDefinition-pachymetry.md)
* [Prism Cover Test](StructureDefinition-prism-cover-test.md)
* [Red Filter Light Test](StructureDefinition-red-filter-light-test.md)
* [Stereopsis Test](StructureDefinition-stereopsis-test.md)
* [Strabismus Exam](StructureDefinition-strabismus-exam.md)
* [Tension Curve](StructureDefinition-tension-curve.md)
* [Worth 4 Dot Test](StructureDefinition-worth-4-dot-test.md)

### ImplementationGuides

* [FHIR4Eyes - A Proposed FHIR Implementation Guide for Ophthalmology](index.md)

### Examples

* [LeftEyeStructureExample (BodyStructure)](BodyStructure-LeftEyeStructureExample.md)
* [RightEyeStructureExample (BodyStructure)](BodyStructure-RightEyeStructureExample.md)
* [Avastin injection scheme - left eye (CarePlan)](CarePlan-AvastinInjectionCarePlanExample.md)
* [DiabeticMacularEdemaConditionExample (Condition)](Condition-DiabeticMacularEdemaConditionExample.md)
* [IntraocularLensExample (Device)](Device-IntraocularLensExample.md)
* [OCTMaculaDiagnosticReportExample (DiagnosticReport)](DiagnosticReport-OCTMaculaDiagnosticReportExample.md)
* [EncounterExample (Encounter)](Encounter-EncounterExample.md)
* [OCTMaculaLeftEyeExample (ImagingStudy)](ImagingStudy-OCTMaculaLeftEyeExample.md)
* [OCTOpticDiscLeftEyeExample (ImagingStudy)](ImagingStudy-OCTOpticDiscLeftEyeExample.md)
* [AvastinMedicationExample (Medication)](Medication-AvastinMedicationExample.md)
* [AvastinDose1AdministrationExample (MedicationAdministration)](MedicationAdministration-AvastinDose1AdministrationExample.md)
* [ConvergenceAssessmentExample (Observation)](Observation-ConvergenceAssessmentExample.md)
* [CorrectedIntraocularPressureLeftEyeExample (Observation)](Observation-CorrectedIntraocularPressureLeftEyeExample.md)
* [CorrectedIntraocularPressureRightEyeExample (Observation)](Observation-CorrectedIntraocularPressureRightEyeExample.md)
* [CoverTestExample (Observation)](Observation-CoverTestExample.md)
* [IntraocularPressureLeftEyeExample (Observation)](Observation-IntraocularPressureLeftEyeExample.md)
* [IntraocularPressureRightEyeExample (Observation)](Observation-IntraocularPressureRightEyeExample.md)
* [NearPointOfConvergenceExample (Observation)](Observation-NearPointOfConvergenceExample.md)
* [OcularMotilityLeftEyeExample (Observation)](Observation-OcularMotilityLeftEyeExample.md)
* [OcularMotilityRightEyeExample (Observation)](Observation-OcularMotilityRightEyeExample.md)
* [PachymetryLeftEyeExample (Observation)](Observation-PachymetryLeftEyeExample.md)
* [PachymetryRightEyeExample (Observation)](Observation-PachymetryRightEyeExample.md)
* [PrismCoverTestExample (Observation)](Observation-PrismCoverTestExample.md)
* [PrismCoverTestPrimaryPositionExample (Observation)](Observation-PrismCoverTestPrimaryPositionExample.md)
* [StereopsisTestExample (Observation)](Observation-StereopsisTestExample.md)
* [StrabismusExamExample (Observation)](Observation-StrabismusExamExample.md)
* [TensionCurveRightEye0800Example (Observation)](Observation-TensionCurveRightEye0800Example.md)
* [TensionCurveRightEye1200Example (Observation)](Observation-TensionCurveRightEye1200Example.md)
* [TensionCurveRightEye1400Example (Observation)](Observation-TensionCurveRightEye1400Example.md)
* [TensionCurveRightEyeExample (Observation)](Observation-TensionCurveRightEyeExample.md)
* [VisualAcuityBinocularExample (Observation)](Observation-VisualAcuityBinocularExample.md)
* [VisualAcuityCorrectedLeftEyeExample (Observation)](Observation-VisualAcuityCorrectedLeftEyeExample.md)
* [VisualAcuityCountingFingersRightEyeExample (Observation)](Observation-VisualAcuityCountingFingersRightEyeExample.md)
* [VisualAcuityPinholeRightEyeExample (Observation)](Observation-VisualAcuityPinholeRightEyeExample.md)
* [VisualAcuityUncorrectedRightEyeExample (Observation)](Observation-VisualAcuityUncorrectedRightEyeExample.md)
* [PacienteEjemplo (Patient)](Patient-PacienteEjemplo.md)
* [PatientExample (Patient)](Patient-PatientExample.md)
* [OphthalmologistExample (Practitioner)](Practitioner-OphthalmologistExample.md)
* [CataractSurgeryProcedureExample (Procedure)](Procedure-CataractSurgeryProcedureExample.md)
* [IntravitrealInjectionProcedureExample (Procedure)](Procedure-IntravitrealInjectionProcedureExample.md)
* [OCTProcedureExample (Procedure)](Procedure-OCTProcedureExample.md)
* [OCTMaculaServiceRequestExample (ServiceRequest)](ServiceRequest-OCTMaculaServiceRequestExample.md)
* [OCTOpticDiscServiceRequestExample (ServiceRequest)](ServiceRequest-OCTOpticDiscServiceRequestExample.md)
