# Intraocular Pressure - FHIR4Eyes - A Proposed FHIR Implementation Guide for Ophthalmology v0.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Intraocular Pressure**

## Resource Profile: Intraocular Pressure 

| | |
| :--- | :--- |
| *Official URL*:https://YasniiSS.github.io/fhir4eyes/StructureDefinition/intraocular-pressure | *Version*:0.4.0 |
| Draft as of 2026-10-19 | *Computable Name*:IntraocularPressure |

 
Represents a single intraocular pressure (IOP) reading, in mmHg. Code is fixed to SNOMED CT 41633001 (Intraocular pressure). 

Represents a single intraocular pressure (IOP) reading, in mmHg. `code` is fixed to SNOMED CT `41633001` (Intraocular pressure), and `value[x]` is a required `Quantity` (`1..1`), constrained by the `inv-iop-range` invariant to between 0 and 80 mmHg.

### Usage

**Tonometry method.** `method` (`0..1`) optionally records the type of tonometer used (for example applanation or non-contact), a concept covered by LOINC `79764-7` (Type of Tonometer).

**Laterality.** `bodySite` (`0..1`) uses the standard `bodySite` extension to reference an [OcularBodyStructure](StructureDefinition-ocular-body-structure.md), following the laterality pattern described in [Guidance](guidance.md).

**Relationship to other profiles.** An `IntraocularPressure` reading may be recorded on its own, may be grouped with other readings across a day as a member of a [TensionCurve](StructureDefinition-tension-curve.md), and may serve as the base reading that a [CorrectedIntraocularPressure](StructureDefinition-corrected-intraocular-pressure.md) references via `derivedFrom`, together with a [Pachymetry](StructureDefinition-pachymetry.md) measurement.

**Examples:** [IOP: right eye](Observation-IntraocularPressureRightEyeExample.md), [IOP: left eye](Observation-IntraocularPressureLeftEyeExample.md), [Tension curve reading 08:00, right eye](Observation-TensionCurveRightEye0800Example.md), [Tension curve reading 12:00, right eye](Observation-TensionCurveRightEye1200Example.md), [Tension curve reading 14:00, right eye](Observation-TensionCurveRightEye1400Example.md)

**Usages:**

* Refer to this Profile: [Corrected Intraocular Pressure](StructureDefinition-corrected-intraocular-pressure.md) and [Tension Curve](StructureDefinition-tension-curve.md)
* Examples for this Profile: [Observation/IntraocularPressureLeftEyeExample](Observation-IntraocularPressureLeftEyeExample.md), [Observation/IntraocularPressureRightEyeExample](Observation-IntraocularPressureRightEyeExample.md), [Observation/TensionCurveRightEye0800Example](Observation-TensionCurveRightEye0800Example.md), [Observation/TensionCurveRightEye1200Example](Observation-TensionCurveRightEye1200Example.md) and [Observation/TensionCurveRightEye1400Example](Observation-TensionCurveRightEye1400Example.md)
* CapabilityStatements using this Profile: [FHIR4Eyes Server Capability Statement](CapabilityStatement-FHIR4EyesCapabilityStatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/fhir4eyes.core|current/StructureDefinition/StructureDefinition-intraocular-pressure.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-intraocular-pressure.csv), [Excel](StructureDefinition-intraocular-pressure.xlsx), [Schematron](StructureDefinition-intraocular-pressure.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "intraocular-pressure",
  "url" : "https://YasniiSS.github.io/fhir4eyes/StructureDefinition/intraocular-pressure",
  "version" : "0.4.0",
  "name" : "IntraocularPressure",
  "title" : "Intraocular Pressure",
  "status" : "draft",
  "date" : "2026-10-19T22:17:00-03:00",
  "publisher" : "FHIR4Eyes Project",
  "contact" : [{
    "name" : "FHIR4Eyes Project",
    "telecom" : [{
      "system" : "url",
      "value" : "https://YasniiSS.github.io/fhir4eyes"
    }]
  },
  {
    "name" : "Yasna Soto",
    "telecom" : [{
      "system" : "url",
      "value" : "https://YasniiSS.github.io/fhir4eyes"
    }]
  }],
  "description" : "Represents a single intraocular pressure (IOP) reading, in mmHg. Code is\r\nfixed to SNOMED CT 41633001 (Intraocular pressure).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001",
      "display" : "World"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation",
      "constraint" : [{
        "key" : "inv-iop-range",
        "severity" : "error",
        "human" : "IOP value must be between 0 and 80 mmHg",
        "expression" : "value.ofType(Quantity).value.empty() or (value.ofType(Quantity).value >= 0 and value.ofType(Quantity).value <= 80)",
        "source" : "https://YasniiSS.github.io/fhir4eyes/StructureDefinition/intraocular-pressure"
      }]
    },
    {
      "id" : "Observation.status",
      "path" : "Observation.status",
      "mustSupport" : true
    },
    {
      "id" : "Observation.category",
      "path" : "Observation.category",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "41633001",
          "display" : "Intraocular pressure"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Observation.subject",
      "path" : "Observation.subject",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.encounter",
      "path" : "Observation.encounter",
      "mustSupport" : true
    },
    {
      "id" : "Observation.effective[x]",
      "path" : "Observation.effective[x]",
      "mustSupport" : true
    },
    {
      "id" : "Observation.performer",
      "path" : "Observation.performer",
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "short" : "The IOP reading, in mmHg",
      "min" : 1,
      "type" : [{
        "code" : "Quantity"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.note",
      "path" : "Observation.note",
      "mustSupport" : true
    },
    {
      "id" : "Observation.bodySite",
      "path" : "Observation.bodySite",
      "mustSupport" : true
    },
    {
      "id" : "Observation.bodySite.extension:bodySiteEye",
      "path" : "Observation.bodySite.extension",
      "sliceName" : "bodySiteEye",
      "short" : "Laterality of the reading, via BodyStructure",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/bodySite"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.bodySite.extension:bodySiteEye.value[x]",
      "path" : "Observation.bodySite.extension.value[x]",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://YasniiSS.github.io/fhir4eyes/StructureDefinition/ocular-body-structure"]
      }]
    },
    {
      "id" : "Observation.method",
      "path" : "Observation.method",
      "short" : "The tonometry method used (e.g. applanation, non-contact) — LOINC 79764-7",
      "mustSupport" : true
    }]
  }
}

```
