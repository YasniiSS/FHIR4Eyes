# Corrected Intraocular Pressure - FHIR4Eyes - A Proposed FHIR Implementation Guide for Ophthalmology v0.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Corrected Intraocular Pressure**

## Resource Profile: Corrected Intraocular Pressure 

| | |
| :--- | :--- |
| *Official URL*:https://YasniiSS.github.io/fhir4eyes/StructureDefinition/corrected-intraocular-pressure | *Version*:0.4.0 |
| Draft as of 2026-11-16 | *Computable Name*:CorrectedIntraocularPressure |

 
Represents an intraocular pressure reading corrected for corneal thickness (pachymetry). Recorded as a separate Observation from the plain IOP reading, referencing both the IOP and pachymetry measurements it was derived from via derivedFrom. 

Represents an intraocular pressure reading corrected for corneal thickness (pachymetry), with the corrected value as a required `Quantity` in mmHg. It is recorded as a separate `Observation` from the plain IOP reading, rather than overwriting or annotating it. `code` is fixed to the laterality-neutral local code `corrected-intraocular-pressure` ([FHIR4EyesCS](CodeSystem-fhir4eyes-cs.md)); instances may add the eye-specific LOINC as a second coding (`96093-0` right eye / `96092-2` left eye, compensated IOP, calculated).

### Usage

**Always derived, never standalone.** `derivedFrom` is `1..*` and only accepts `Reference(IntraocularPressure | Pachymetry)`: a corrected reading always references the specific [IntraocularPressure](StructureDefinition-intraocular-pressure.md) reading and [Pachymetry](StructureDefinition-pachymetry.md) measurement it was calculated from.

**Within a tension curve.** A [TensionCurve](StructureDefinition-tension-curve.md) may include a `CorrectedIntraocularPressure` as one of its members, alongside plain `IntraocularPressure` readings. Pachymetry is not referenced directly from the curve, since the corrected reading already references it via `derivedFrom`; see the worked example and diagram on the [TensionCurve](StructureDefinition-tension-curve.md) page.

**Laterality.** `bodySite` (`0..1`) uses the standard `bodySite` extension to reference an [OcularBodyStructure](StructureDefinition-ocular-body-structure.md).

The same `derivedFrom` pattern is reused by [OphthalmicVisualAcuity](StructureDefinition-ophthalmic-visual-acuity.md) for pinhole measurements.

**Examples:** [Corrected IOP: right eye](Observation-CorrectedIntraocularPressureRightEyeExample.md), [Corrected IOP: left eye](Observation-CorrectedIntraocularPressureLeftEyeExample.md)

**Usages:**

* Refer to this Profile: [Tension Curve](StructureDefinition-tension-curve.md)
* Examples for this Profile: [Observation/CorrectedIntraocularPressureLeftEyeExample](Observation-CorrectedIntraocularPressureLeftEyeExample.md) and [Observation/CorrectedIntraocularPressureRightEyeExample](Observation-CorrectedIntraocularPressureRightEyeExample.md)
* CapabilityStatements using this Profile: [FHIR4Eyes Server Capability Statement](CapabilityStatement-FHIR4EyesCapabilityStatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/fhir4eyes.core|current/StructureDefinition/StructureDefinition-corrected-intraocular-pressure.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-corrected-intraocular-pressure.csv), [Excel](StructureDefinition-corrected-intraocular-pressure.xlsx), [Schematron](StructureDefinition-corrected-intraocular-pressure.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "corrected-intraocular-pressure",
  "url" : "https://YasniiSS.github.io/fhir4eyes/StructureDefinition/corrected-intraocular-pressure",
  "version" : "0.4.0",
  "name" : "CorrectedIntraocularPressure",
  "title" : "Corrected Intraocular Pressure",
  "status" : "draft",
  "date" : "2026-11-16T21:59:20-03:00",
  "publisher" : "FHIR4Eyes Project",
  "contact" : [{
    "name" : "FHIR4Eyes Project",
    "telecom" : [{
      "system" : "url",
      "value" : "https://YasniiSS.github.io/fhir4eyes"
    }]
  },
  {
    "name" : "Yasna Soto",
    "telecom" : [{
      "system" : "url",
      "value" : "https://YasniiSS.github.io/fhir4eyes"
    }]
  }],
  "description" : "Represents an intraocular pressure reading corrected for corneal thickness\n(pachymetry). Recorded as a separate Observation from the plain IOP reading, referencing\nboth the IOP and pachymetry measurements it was derived from via derivedFrom.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001",
      "display" : "World"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation"
    },
    {
      "id" : "Observation.status",
      "path" : "Observation.status",
      "mustSupport" : true
    },
    {
      "id" : "Observation.category",
      "path" : "Observation.category",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.category:exam",
      "path" : "Observation.category",
      "sliceName" : "exam",
      "min" : 1,
      "max" : "1",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "exam",
          "display" : "Exam"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "short" : "Identifies this as a corrected IOP reading. LOINC 96093-0/96092-2 (compensated IOP) exist but may not be equivalent to CCT-based correction; not used",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://YasniiSS.github.io/fhir4eyes/CodeSystem/fhir4eyes-cs",
          "code" : "corrected-intraocular-pressure",
          "display" : "Intraocular pressure corrected for central corneal thickness"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Observation.subject",
      "path" : "Observation.subject",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.encounter",
      "path" : "Observation.encounter",
      "mustSupport" : true
    },
    {
      "id" : "Observation.effective[x]",
      "path" : "Observation.effective[x]",
      "mustSupport" : true
    },
    {
      "id" : "Observation.performer",
      "path" : "Observation.performer",
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "short" : "The corrected IOP value, in mmHg",
      "min" : 1,
      "type" : [{
        "code" : "Quantity"
      }],
      "patternQuantity" : {
        "system" : "http://unitsofmeasure.org",
        "code" : "mm[Hg]"
      },
      "mustSupport" : true
    },
    {
      "id" : "Observation.note",
      "path" : "Observation.note",
      "mustSupport" : true
    },
    {
      "id" : "Observation.bodySite",
      "path" : "Observation.bodySite",
      "mustSupport" : true
    },
    {
      "id" : "Observation.bodySite.extension:bodySiteEye",
      "path" : "Observation.bodySite.extension",
      "sliceName" : "bodySiteEye",
      "short" : "Laterality of the reading, via BodyStructure",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/bodySite|5.4.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.bodySite.extension:bodySiteEye.value[x]",
      "path" : "Observation.bodySite.extension.value[x]",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://YasniiSS.github.io/fhir4eyes/StructureDefinition/ocular-body-structure"]
      }]
    },
    {
      "id" : "Observation.derivedFrom",
      "path" : "Observation.derivedFrom",
      "short" : "The IOP and pachymetry measurements this corrected value was derived from",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://YasniiSS.github.io/fhir4eyes/StructureDefinition/intraocular-pressure",
        "https://YasniiSS.github.io/fhir4eyes/StructureDefinition/pachymetry"]
      }],
      "mustSupport" : true
    }]
  }
}

```
